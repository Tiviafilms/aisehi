import csv
import pyrebase
from Cred import Cred
from Config import Config
import time
import math
from Logger import Logger

class FDB:

    def __init__(self, status, app):
        firebase = pyrebase.initialize_app(Cred.FIREBASE_CONF)
        self.db = firebase.database()
        print(f"DB connect ok: {status}")
        self.log = Logger(app)
    
    async def add_user(self, message):
        username = "N/A"
        if message.chat.username:
            username = message.chat.username
        data = {
            "username": username,
            "id": str(message.chat.id),
            "first_name": message.chat.first_name,
            "started": str(math.floor(time.time())),
            "last_searched": "N/A",
            "points": "0",
            "status": "user",
            "blocked": "0",
            "safe": "0"
        }
        self.db.child(f"{Config.BOT_DB_PATH}/users/{str(message.chat.id)}").set(data)
        await self.log.log(message.chat.id, "User added to the database")
        print(f"{message.chat.id} - User added to the database")
    
    async def check_user(self, message):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(message.chat.id)}").get().val()
        # user in db
        if data:
            # blocked user
            if int(data["blocked"]) == 1:
                return False

            # normal user
            elif int(data["blocked"]) == 0:
                return True
        # user not in db. need to add
        else:
            await self.add_user(message)
            return True
    
    async def add_last_searched(self, user,searched_txt):
        self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/last_searched").set(searched_txt)
        await self.log.log(user, f"User searched: {searched_txt}")

    def get_last_searched(self, user):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/last_searched").get().val()
        if data:
            return data
        else:
            return None
        
    async def add_safe(self, user, on_or_off):
        self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/safe").set(on_or_off)
        mod = "off"
        if int(on_or_off) == 1:
            mod = "on"
        await self.log.log(user, f"User changed search mod: {mod}")

    def get_safe(self, user):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/safe").get().val()
        # off
        if data == "0":
            return False
        # on
        elif data == "1":
            return True
        
        else:
            return None
        
    def block_user(self, user):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/blocked").get().val()
        if data == "1":
            return False
        elif data == "0":
            self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/blocked").set("1")
            return True
        else:
            return None

    def unblock_user(self, user):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/blocked").get().val()
        if data == "1":
            self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/blocked").set("0")
            return True
        elif data == "0":
            return False
        else:
            return None

    def add_points(self, user):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/points").get().val()      
        if data:
            points = int(data) + 1
            self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}/points").set(str(points))


    def user_exists(self, user):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}").get().val()
        if data:
            return True
        else:
            return False
        

    def get_user_details(self, user):
        data = self.db.child(f"{Config.BOT_DB_PATH}/users/{str(user)}").get().val()
        if data:
            return data
        else:
            return None
        
