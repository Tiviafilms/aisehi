class Config(object):
    # DB data - it is okey you don't need to edit this BOT_NAME and BOT_DB_PATH
    BOT_NAME = "movie-bot"
    BOT_DB_PATH = f"bot/{BOT_NAME}/"

    # TG
    BOT_LINK = "https://t.me/mirrorl2bot"
    BOT_USERNAME = f"@{BOT_LINK.split('/')[-1]}"
    
    # Provide any number of admin list
    ADMIN = [5176829003, 1915029649]
    
    # Logging channel id
    LOGGER_CHANNEL_ID = -1002062763700
    
    # Group id that bot is going to add
    GROUP_ID = -1002125756767
    
    # Channe; that user must subscribe to search
    SUBSCRIBE_CHANNEL = -1001667864913
    SUBSCRIBE_CHANNEL_URL = "https://t.me/ztoxy"
    
    # Contact username
    CONTACT = "@upekshaip"

    # DOOD STREAM
    DOOD_KEY = "13527p8pcv54of4yjeryk"
    DOOD_SEARCH = f"https://doodapi.com/api/search/videos?key={DOOD_KEY}&search_term="
    DOOD_FILE= f"https://doodapi.com/api/file/info?key={DOOD_KEY}&file_code="
    DOOD_DL= f"https://ds2video.com"
    DOOD_DL2 = "https://dood.ws"
    MAX_LOAD_COUNT = 3

    #SHAREUS.IO
    SHAREUS_API_KEY = "mkaEbaAGhLQVUoy0yXU8J6LaEGp2"
    SHAREUS_DIRECT_LINK = f"https://api.shareus.io/direct_link?api_key={SHAREUS_API_KEY}&pages=3&link="
    SHARE_US_API = f"https://api.shareus.io/easy_api?key={SHAREUS_API_KEY}&link="
    # SHAREUS_GET_LINK = f"https://api.shareus.io/easy_api?key={SHAREUS_API_KEY}&link="


    # COMMANDS
    BROADCAST_COMMAND = "/broadcast"
    BLOCK_USER_COMMAND = "/block"
    UNBLOCK_USER_COMMAND = "/unblock"
    GET_USER_DETAILS_COMMAND = "/user"
    RUN_TIME = "/run_time"
    GET_ID_COMMAND = "/id"
    SAFE_SEARCH_COMMAND = "/safe_search"
    TALK_TO_ADMIN_COMMAND = "/admin"
    CUSTOM_MSG_COMMAND = "/user"
    BROADCAST_SYMBOL = "###"

    
    # MESSAGES
    START_MSG = f"Welcome to {BOT_USERNAME}. Send /help to see the instructions"
    HELP_MESSAGE = f"**All the user commands**\n \n/start - __Starts the bot.__\n/help - __Send help commands__\n{GET_ID_COMMAND} - __Get your information__\n{TALK_TO_ADMIN_COMMAND} - __Contact admin directly__\n{SAFE_SEARCH_COMMAND} - __Your safe search mod__\n \nFor help contact {CONTACT}"
    ADMIN_HELP_MESSAGE = f"**All the admin commands**\n \n/start - __Starts the bot.__\n/help - __Send help commands__\n{GET_ID_COMMAND} - __Get your information__\n{BLOCK_USER_COMMAND} - __Block user__\n{UNBLOCK_USER_COMMAND} - __Unblock user__\n{RUN_TIME} - Check bot's running time\n{SAFE_SEARCH_COMMAND} - __Your safe search mod__\n{CUSTOM_MSG_COMMAND} - __Contact any user__\n{BROADCAST_COMMAND} - __Reply any message to broadcast__\n`{BROADCAST_SYMBOL}` - __Send any message with `{BROADCAST_SYMBOL}` and it will broadcasted to all the users__"

    # DO NOT TOUCH THIS!
    starting_point = []