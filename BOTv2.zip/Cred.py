# Telegram API
class Cred:
    # Add your telegram APP info here
    API_ID = 123456
    API_HASH = "abcdefg123456789asdasda4562156"
    BOT_TOKEN = "abcdefg123456789asdasda4562156"

    # Add your firebase config here
    FIREBASE_CONF = {
        'apiKey': "abcdefg123456789asdasda4562156",
        'authDomain': "abcd.firebaseapp.com",
        'projectId': "abcd-bot",
        'storageBucket': "abcd-bot.abcd.com",
        'messagingSenderId': "123456789",
        'appId': "123456789123456789",
        'databaseURL': "https://abcd-bot-abcd.asia-southeast.firebasedatabase.app"
    }