from Config import Config
import requests
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.types import InputMediaPhoto, InputMediaVideo
from pyrogram.enums import ChatMemberStatus
from DB import FDB
import math
import time
from datetime import datetime
from better_profanity import profanity
from Logger import Logger

class Process:
    def __init__(self, app):
        self.app = app
        self.dbh = FDB("process db ok", app)
        self.db = self.dbh.db
        self.log = Logger(app)

    def shareus_cover(self, url):
        res = requests.get(f"{Config.SHARE_US_API}{url}")
        response = ""
        if res.status_code == 200:
            response = res.text
        else:
            response = f"{Config.SHAREUS_DIRECT_LINK}{url}"
        return response
    
    def get_video_url(self, file_code):
        try:
            res = requests.get(f"{Config.DOOD_FILE}{file_code}")
            if res.status_code == 200 and res.json()["status"] == 200:
                data = res.json()["result"][0]
                url = f"{Config.DOOD_DL}{data['protected_dl']}"
                url2 = f"{Config.DOOD_DL2}{data['protected_dl']}"
                size = data['size']
                return url, self.shareus_cover(url2), size

            else:
                print("Conn ERR")
                return None, None, None
        except:
            print("Connection ERR")
            return None, None, None

    async def search_movie(self, message, search_text, load_count):
        if load_count != 0:
            await message.edit_message_text("♻️ Processing...")
            message = message.message
        else:
            await self.app.send_message(message.chat.id, "♻️ Processing...")
            await self.dbh.add_last_searched(message.chat.id, message.text)
        try:
            res = requests.get(f"{Config.DOOD_SEARCH}{search_text}")
            if res.status_code == 200 and res.json()["status"] == 200:
                data = res.json()["result"]

                if self.dbh.get_safe(message.chat.id):
                    data = self.filter_data(data)
                
                if len(data) > 0:
                    count = load_count * Config.MAX_LOAD_COUNT
                    # for movie in data:
                    for i in range(Config.MAX_LOAD_COUNT):
                        if count < (Config.MAX_LOAD_COUNT * load_count) + Config.MAX_LOAD_COUNT:
                            file_code = data[count]["file_code"]
                            splash_img = data[count]["splash_img"]
                            views = data[count]["views"]
                            single_img = data[count]["single_img"]
                            title = data[count]["title"]
                            
                            print(count,"-",title)
                            length = self.timeFormatter(int(data[count]["length"]) * 1000)
                            movie_url, movie_url2, size = self.get_video_url(file_code)
                            size = self.humanbytes(int(size))

                            if movie_url is not None:
                                await self.send_movie(message, file_code, splash_img, views, single_img, title, length, movie_url, size, movie_url2)
                        count += 1
                        time.sleep(2)
                    if len(data) > Config.MAX_LOAD_COUNT:
                        await self.app.send_message(message.chat.id, "Press bellow to load more",reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Load more 🔄", callback_data=f"load_{load_count + 1}")]]))
                else:
                    print("Not found any data")
                    await self.app.send_message(message.chat.id, f"Sorry did not found the movie. May be turn off the safe search mod will find your content `{Config.SAFE_SEARCH_COMMAND} off`. Press the button to send a request to add last searched item.",reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Request to add movie", callback_data=f"req_add")]
                ]
            ))
                    

            else:
                return None
        except IndexError:
            pass
        except Exception as e:
            print(e)
            return None
    
    async def multi_search_movie(self, message, search_text, load_count, word_index):
        data = {}
        count = 0
        if load_count == 0 and word_index == 0:
            await self.app.send_message(message.chat.id, "♻️ Processing...")
            await self.dbh.add_last_searched(message.chat.id, message.text)
        else:
            await message.edit_message_text("♻️ Processing...")
            message = message.message
        try:
            key_word = search_text.split("&")[word_index].strip()
            res = requests.get(f"{Config.DOOD_SEARCH}{key_word}")
            if res.status_code == 200 and res.json()["status"] == 200:
                data = res.json()["result"]

                if self.dbh.get_safe(message.chat.id):
                    data = self.filter_data(data)
                
                if len(data) > 0:
                    count = load_count * Config.MAX_LOAD_COUNT
                    # for movie in data:
                    for i in range(Config.MAX_LOAD_COUNT):
                        if count < (Config.MAX_LOAD_COUNT * load_count) + Config.MAX_LOAD_COUNT:
                            file_code = data[count]["file_code"]
                            splash_img = data[count]["splash_img"]
                            views = data[count]["views"]
                            single_img = data[count]["single_img"]
                            title = data[count]["title"]
                            
                            print(count,"-",title)
                            length = self.timeFormatter(int(data[count]["length"]) * 1000)
                            movie_url, movie_url2, size = self.get_video_url(file_code)
                            size = self.humanbytes(int(size))

                            if movie_url is not None:
                                await self.send_movie(message, file_code, splash_img, views, single_img, title, length, movie_url, size, movie_url2)
                        count += 1
                        time.sleep(2)
                    if len(data) > Config.MAX_LOAD_COUNT:
                        await self.app.send_message(message.chat.id, "Press bellow to load more",reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Load more 🔄", callback_data=f"multi_{load_count + 1}-{word_index}")]]))
                else:
                    print("Not found any data")
                    await self.app.send_message(message.chat.id, f"Sorry did not found the movie. May be turn off the safe search mod will find your content `{Config.SAFE_SEARCH_COMMAND} off`. Press the button to send a request to add last searched item.",reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("Request to add movie", callback_data=f"req_add")]
                    ]))
                    
                    word_index += 1
                    await self.app.send_message(message.chat.id, f"Press bellow to load next key-word: {search_text.split('&')[word_index].strip()}",reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("Load more 🔄", callback_data=f"multi_0-{word_index}")]]))
                    

            else:
                return None
        except IndexError:
            if len(data) >= count and len(search_text.split("&")) > word_index + 1:
                word_index += 1
                await self.app.send_message(message.chat.id, f"Press bellow to load next key-word: {search_text.split('&')[word_index].strip()}",reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("Load more 🔄", callback_data=f"multi_0-{word_index}")]]))
            else:
                pass
        except Exception as e:
            print(e)
            return None
    
    
    async def send_movie(self,message, file_code, splash_img, views, single_img, title, length, movie_url, size, movie_url2):
        # await self.app.send_message(message.chat.id, )
        await self.app.send_photo(
            message.chat.id,
            single_img, # DO not change this line
            caption=f"__Movie name:__ **{title}**\n \n__Length:__ **{length}**\n__Views:__ **{views}**\n__Size:__ **{size}**",
            reply_markup=InlineKeyboardMarkup(
                [
                    [InlineKeyboardButton("Splash image 🖼", url=splash_img)],
                    [InlineKeyboardButton("Movie URL 1 🔗", url=movie_url)],
                    [InlineKeyboardButton("Movie URL 2 🔗", url=movie_url2)],
                ]
            )
        )


    async def handle_movie_req(self, query):
        searched = self.dbh.get_last_searched(query.message.chat.id)
        await query.edit_message_text(f'Your request has been sent to the admin. Thank you!\n \nRequest: {searched}')
        if searched == "N/A" or searched == None:
            self.app.send_message(query.message.chat.id, "Sorry! Try again...")
        else:
            username = "N/A"
            if query.message.chat.username:
                username = f"@{query.message.chat.username}"

            msg = f"User ID: {query.message.chat.id}\nUser first name: {query.message.chat.first_name}\nUsername: {username}\nDate: {query.message.date}\n \nRequest: {searched}"
            for admin in Config.ADMIN:
                await self.app.send_message(admin, msg, reply_markup=InlineKeyboardMarkup(
                [
                    [InlineKeyboardButton("Send default message ✅", callback_data=f"dm_{query.message.chat.id}")],
                    [InlineKeyboardButton("Send custom message ⚠️", callback_data=f"cm_{query.message.chat.id}")]
                ]
            ))
            await self.log.log(query.message.chat.id, f"User requested a movie: {searched}")
        

    def start(self):
        _format = {
            "username": "0",
            "id": "0",
            "first_name": "0",
            "started": str(math.floor(time.time())),
            "last_searched": "0",
            "points": "0",
            "status": "bot",
            "blocked": "0",
            "safe": "0"
        }
        _format_group = {
            "username": "0",
            "id": f"{str(Config.GROUP_ID)}",
            "first_name": "0",
            "started": str(math.floor(time.time())),
            "last_searched": "0",
            "points": "0",
            "status": "group",
            "blocked": "0",
            "safe": "0"
        }
        self.db.child(f"{Config.BOT_DB_PATH}/users/{str(0)}").set(_format)
        self.db.child(f"{Config.BOT_DB_PATH}/users/{str(Config.GROUP_ID)}").set(_format_group)
        print("db created")
        Config.starting_point.append(time.time())

    
    async def handle_block(self, message):
        if Config.BLOCK_USER_COMMAND == message.text:
            await self.app.send_message(message.chat.id, f"Send this command like this:\n\n`{Config.BLOCK_USER_COMMAND} user_id`")
            return
        user = str(message.text).split(f"{Config.BLOCK_USER_COMMAND} ")[-1]

        if int(message.chat.id) in Config.ADMIN:
            if int(user) in Config.ADMIN:
                await self.app.send_message(message.chat.id, "Admins cannot block or unblock admins!")
                return
            ans = self.dbh.block_user(user)
            if ans == True:
                await self.app.send_message(message.chat.id, "User blocked")
                await self.log.log(f"{message.chat.id}", f"Admin blocked the user: {user}")
            elif ans == False:
                await self.app.send_message(message.chat.id, "User already blocked!")
            else:
                await self.app.send_message(message.chat.id, "Something went wrong! Try again...")
                
                


    async def handle_unblock(self, message):
        if Config.UNBLOCK_USER_COMMAND == message.text:
            await self.app.send_message(message.chat.id, f"Send this command like this:\n\n`{Config.UNBLOCK_USER_COMMAND} user_id`")
            return
        user = str(message.text).split(f"{Config.UNBLOCK_USER_COMMAND} ")[-1]
        
        if int(message.chat.id) in Config.ADMIN:
            if int(user) in Config.ADMIN:
                await self.app.send_message(message.chat.id, "Admins cannot block or unblock admins!")
                return
            ans = self.dbh.unblock_user(user)
            if ans == True:
                await self.app.send_message(message.chat.id, "User unblocked")
                await self.log.log(f"{message.chat.id}", f"Admin unblocked the user: {user}")
            elif ans == False:
                await self.app.send_message(message.chat.id, "User already unblocked!")
            else:
                await self.app.send_message(message.chat.id, "Something went wrong! Try again...")


        # Checking Runtime
    async def check_runtime(self, message):
        if int(message.chat.id) in Config.ADMIN:
            now = time.time()
            now = math.floor((now - Config.starting_point[0]) * 1000)
            now = self.timeFormatter(now)
            await self.app.send_message(
                message.chat.id, f"__Bot running time -__ **{now}**")
            await self.log.log(message.chat.id, f"Admin checked the runtime: **{now}**")
            
    # Time formatter
    def timeFormatter(self, milliseconds: int) -> str:
        seconds, milliseconds = divmod(int(milliseconds), 1000)
        minutes, seconds = divmod(seconds, 60)
        hours, minutes = divmod(minutes, 60)
        days, hours = divmod(hours, 24)
        tmp = ((str(days) + "d, ") if days else "") + \
            ((str(hours) + "h, ") if hours else "") + \
            ((str(minutes) + "m, ") if minutes else "") + \
            ((str(seconds) + "s, ") if seconds else "") + \
            ((str(milliseconds) + "ms, ") if milliseconds else "")
        return tmp[:-2]

    async def send_broadcast(self, message):
        user_lst = self.db.child(f"{Config.BOT_DB_PATH}/users").get().each()
        user_lst = [int(user.key()) for user in user_lst]
        msg = str(message.text).replace(Config.BROADCAST_SYMBOL, "")
        try:
            for user in user_lst:
                try:
                    if user != 0:
                        await self.app.send_message(user, msg)
                except:
                    pass
            await self.app.send_message(
                message.chat.id, "**Promo message sent to all other users**")
            await self.log.log(message.chat.id, f"Admin broadcasted a message\nMessage: {msg}")

        except:
            pass
            


    # Send promotion messages to all the users
    async def send_promo_message(self, message):
        user_lst = self.db.child(f"{Config.BOT_DB_PATH}/users").get().each()
        user_lst = [int(user.key()) for user in user_lst]

        try:
            reply = message.reply_to_message
            for user in user_lst:
                try:
                    if user != 0:
                        if reply.text:
                            await self.app.send_message(user, reply.text)
                        if reply.video:
                            await self.app.send_video(user, reply.video.file_id,
                                                caption=reply.caption)
                        if reply.photo:
                            await self.app.send_photo(user, reply.photo.file_id,
                                                caption=reply.caption)
                        if reply.sticker:
                            await self.app.send_sticker(user, reply.sticker.file_id)
                        if reply.document:
                            await self.app.send_document(user, reply.document.file_id,
                                                   caption=reply.caption)
                        if reply.audio:
                            await self.app.send_audio(user, reply.audio.file_id,
                                                caption=reply.caption)
                        if reply.animation:
                            await self.app.send_animation(user, reply.animation.file_id,
                                                    caption=reply.caption)
                except:
                    pass

            await self.app.send_message(
                message.chat.id, "**Promo message sent to all other users**")
            await self.log.log(message.chat.id, f"Admin broadcasted a message")
        except:
            await self.app.send_message(
                message.chat.id, "**Cannot send the promo message. Try repling to a massege\n Or some error occured**")
            
    
    async def get_id(self, message):
        username = "N/A"
        if message.chat.username:
            username = message.chat.username
        msg = f"Your details\n \nID: `{message.chat.id}`\nUsername: `{username}`\nFirst Name: {message.chat.first_name}\nPersonal link: {Config.BOT_LINK}?start={message.chat.id}"
        
        data = self.dbh.get_user_details(message.chat.id)
        if data:
            safe = "off"
            if data["safe"] == "1":
                safe = "on"
            msg += f"\nSafe mod: {safe}\nPoints: {data['points']}\nLast searched: {data['last_searched']}\n \n**If you shared the `Personal link` to other users and if someone starts the bot with your link you will get 1 point. Maybe you will become a winner!** 🥳"
        
        await self.app.send_message(message.chat.id, msg)
        await self.log.log(message.chat.id, f"User checked the id.\n**{msg}**")

    # Check the usage of the bot
    async def is_user_in_channel(self, message):
        try:
            cht_member = await self.app.get_chat_member(
                Config.SUBSCRIBE_CHANNEL, message.chat.id)
            if cht_member.status == ChatMemberStatus.MEMBER or cht_member.status == ChatMemberStatus.OWNER or cht_member.status == ChatMemberStatus.ADMINISTRATOR:
                return True

        except:

            text = f"__To use this bot you needs to subscribe <a href='{Config.SUBSCRIBE_CHANNEL_URL}'>this</a> Telegram channel.__\nAfter you join the channel, **You can search movies** ❤️\n \n \n__Developed by @upekshaip__"
            button = InlineKeyboardButton(
                "Join Channel", url=Config.SUBSCRIBE_CHANNEL_URL)
            keyboard = InlineKeyboardMarkup([[button]])
            # Use the send_message() method to send the message with the button
            await self.app.send_message(
                chat_id=message.chat.id,
                text=text,
                reply_markup=keyboard
            )
            return False
        
        
    def filter_data(self, data):
        modified = []
        for movie in data:
            if not self.check_censor(movie["title"]):
                modified.append(movie)
        return modified

    def check_censor(self, txt):
        dirty_text = ["booty","Niksindian","Milf", "tits","notmygrandpa", "mom", "sister", "family","taboo" ,"Blackmail","daddy", "fck","Fked","DRCSSKMHD","Swap","suck","streamtape","incext","cuckold","bdsm","roleplay", "porn", "xvideos", "xhamster", "pornhub", "phub", "hardcore" , "softcore" ,"mommy",'4r5e', '5h1t', '5hit', 'a55', 'anal', 'anus', 'ar5e', 'arrse', 'arse', 'ass', 'ass-fucker', 'asses', 'assfucker', 'assfukka', 'asshole', 'assholes', 'asswhole', 'a_s_s', 'b!tch', 'b00bs', 'b17ch', 'b1tch', 'ballbag', 'balls', 'ballsack', 'bastard', 'beastial', 'beastiality', 'bellend', 'bestial', 'bestiality', 'bi+ch', 'biatch', 'bitch', 'bitcher', 'bitchers', 'bitches', 'bitchin', 'bitching', 'bloody', 'blow job', 'blowjob', 'blowjobs', 'boiolas', 'bollock', 'bollok', 'boner', 'boob', 'boobs', 'booobs', 'boooobs', 'booooobs', 'booooooobs', 'breasts', 'buceta', 'bugger', 'bum', 'bunny fucker', 'butt', 'butthole', 'buttmuch', 'buttplug', 'c0ck', 'c0cksucker', 'carpet muncher', 'cawk', 'chink', 'cipa', 'cl1t', 'clit', 'clitoris', 'clits', 'cnut', 'cock', 'cock-sucker', 'cockface', 'cockhead', 'cockmunch', 'cockmuncher', 'cocks', 'cocksuck ', 'cocksucked ', 'cocksucker', 'cocksucking', 'cocksucks ', 'cocksuka', 'cocksukka', 'cok', 'cokmuncher', 'coksucka', 'coon', 'cox', 'crap', 'cum', 'cummer', 'cumming', 'cums', 'cumshot', 'cunilingus', 'cunillingus', 'cunnilingus', 'cunt', 'cuntlick ', 'cuntlicker ', 'cuntlicking ', 'cunts', 'cyalis', 'cyberfuc', 'cyberfuck ', 'cyberfucked ', 'cyberfucker', 'cyberfuckers', 'cyberfucking ', 'd1ck', 'damn', 'dick', 'dickhead', 'dildo', 'dildos', 'dink', 'dinks', 'dirsa', 'dlck', 'dog-fucker', 'doggin', 'dogging', 'donkeyribber', 'doosh', 'duche', 'dyke', 'ejaculate', 'ejaculated', 'ejaculates ', 'ejaculating ', 'ejaculatings', 'ejaculation', 'ejakulate', 'f u c k', 'f u c k e r', 'f4nny', 'fag', 'fagging', 'faggitt', 'faggot', 'faggs', 'fagot', 'fagots', 'fags', 'fanny', 'fannyflaps', 'fannyfucker', 'fanyy', 'fatass', 'fcuk', 'fcuker', 'fcuking', 'feck', 'fecker', 'felching', 'fellate', 'fellatio', 'fingerfuck ', 'fingerfucked ', 'fingerfucker ', 'fingerfuckers', 'fingerfucking ', 'fingerfucks ', 'fistfuck', 'fistfucked ', 'fistfucker ', 'fistfuckers ', 'fistfucking ', 'fistfuckings ', 'fistfucks ', 'flange', 'fook', 'fooker', 'fuck', 'fucka', 'fucked', 'fucker', 'fuckers', 'fuckhead', 'fuckheads', 'fuckin', 'fucking', 'fuckings', 'fuckingshitmotherfucker', 'fuckme ', 'fucks', 'fuckwhit', 'fuckwit', 'fudge packer', 'fudgepacker', 'fuk', 'fuker', 'fukker', 'fukkin', 'fuks', 'fukwhit', 'fukwit', 'fux', 'fux0r', 'f_u_c_k', 'gangbang', 'gangbanged ', 'gangbangs ', 'gaylord', 'gaysex', 'goatse', 'God', 'god-dam', 'god-damned', 'goddamn', 'goddamned', 'hardcoresex ', 'hell', 'heshe', 'hoar', 'hoare', 'hoer', 'homo', 'hore', 'horniest', 'horny', 'hotsex', 'jack-off ', 'jackoff', 'jap', 'jerk-off ', 'jism', 'jiz ', 'jizm ', 'jizz', 'kawk', 'knob', 'knobead', 'knobed', 'knobend', 'knobhead', 'knobjocky', 'knobjokey', 'kock', 'kondum', 'kondums', 'kum', 'kummer', 'kumming', 'kums', 'kunilingus', 'l3i+ch', 'l3itch', 'labia', 'lmfao', 'lust', 'lusting', 'm0f0', 'm0fo', 'm45terbate', 'ma5terb8', 'ma5terbate', 'masochist', 'master-bate', 'masterb8', 'masterbat*', 'masterbat3', 'masterbate', 'masterbation', 'masterbations', 'masturbate', 'mo-fo', 'mof0', 'mofo', 'mothafuck', 'mothafucka', 'mothafuckas', 'mothafuckaz', 'mothafucked ', 'mothafucker', 'mothafuckers', 'mothafuckin', 'mothafucking ', 'mothafuckings', 'mothafucks', 'mother fucker', 'motherfuck', 'motherfucked', 'motherfucker', 'motherfuckers', 'motherfuckin', 'motherfucking', 'motherfuckings', 'motherfuckka', 'motherfucks', 'muff', 'mutha', 'muthafecker', 'muthafuckker', 'muther', 'mutherfucker', 'n1gga', 'n1gger', 'nazi', 'nigg3r', 'nigg4h', 'nigga', 'niggah', 'niggas', 'niggaz', 'nigger', 'niggers ', 'nob', 'nob jokey', 'nobhead', 'nobjocky', 'nobjokey', 'numbnuts', 'nutsack', 'orgasim ', 'orgasims ', 'orgasm', 'orgasms ', 'p0rn', 'pawn', 'pecker', 'penis', 'penisfucker', 'phonesex', 'phuck', 'phuk', 'phuked', 'phuking', 'phukked', 'phukking', 'phuks', 'phuq', 'pigfucker', 'pimpis', 'piss', 'pissed', 'pisser', 'pissers', 'pisses ', 'pissflaps', 'pissin ', 'pissing', 'pissoff ', 'poop', 'porn', 'porno', 'pornography', 'pornos', 'prick', 'pricks ', 'pron', 'pube', 'pusse', 'pussi', 'pussies', 'pussy', 'pussys ', 'rectum', 'retard', 'rimjaw', 'rimming', 's hit', 's.o.b.', 'sadist', 'schlong', 'screwing', 'scroat', 'scrote', 'scrotum', 'semen', 'sex', 'sh!+', 'sh!t', 'sh1t', 'shag', 'shagger', 'shaggin', 'shagging', 'shemale', 'shi+', 'shit', 'shitdick', 'shite', 'shited', 'shitey', 'shitfuck', 'shitfull', 'shithead', 'shiting', 'shitings', 'shits', 'shitted', 'shitter', 'shitters ', 'shitting', 'shittings', 'shitty ', 'skank', 'slut', 'sluts', 'smegma', 'smut', 'snatch', 'son-of-a-bitch', 'spac', 'spunk', 's_h_i_t', 't1tt1e5', 't1tties', 'teets', 'teez', 'testical', 'testicle', 'tit', 'titfuck', 'tits', 'titt', 'tittie5', 'tittiefucker', 'titties', 'tittyfuck', 'tittywank', 'titwank', 'tosser', 'turd', 'tw4t', 'twat', 'twathead', 'twatty', 'twunt', 'twunter', 'v14gra', 'v1gra', 'vagina', 'viagra', 'vulva', 'w00se', 'wang', 'wank', 'wanker', 'wanky', 'whoar', 'whore', 'willies', 'willy', 'xrated', 'xxx']
        dirty_text2 = []
        for key in dirty_text:
            dirty_text2.append(key.lower())
        words = str(txt).lower().split(" ")
        all_words = dirty_text2 + dirty_text
        for key in all_words:
            if key in str(txt).lower():
                return True

        if dirty_text in words:
            return True
        if dirty_text2 in words:
            return True
        
        profanity.load_censor_words(all_words)
        res = profanity.contains_profanity(txt)
        return res
    
    async def handle_safe_search(self, message):
        if message.text == Config.SAFE_SEARCH_COMMAND:
            await self.app.send_message(message.chat.id, f"You need to send the command like `{Config.SAFE_SEARCH_COMMAND} on` or `{Config.SAFE_SEARCH_COMMAND} off`")
            return
        on_or_off = str(message.text).split(f"{Config.SAFE_SEARCH_COMMAND} ")[-1]
        if on_or_off.lower() == "off":
            await self.dbh.add_safe(message.chat.id, "0")
            await self.app.send_message(message.chat.id, "Safe search mod turned off")
        elif on_or_off.lower() == "on":
            await self.dbh.add_safe(message.chat.id, "1")
            await self.app.send_message(message.chat.id, "Safe search mod turned on")

        else:
            await self.app.send_message(message.chat.id, f"You need to send the command like `{Config.SAFE_SEARCH_COMMAND} on` or `{Config.SAFE_SEARCH_COMMAND} off`")

    async def handle_start(self, message):
        if message.text == "/start":
            await self.app.send_message(message.chat.id, f"Hello {message.chat.first_name},\n{Config.START_MSG}")
            await self.log.log(message.chat.id, f"User started the bot")
        else:
            user = str(message.text).split("/start ")[-1]
            if self.dbh.user_exists(user) and not self.dbh.user_exists(message.chat.id):
                await self.dbh.add_user(message)
                self.dbh.add_points(user)
                await self.log.log(message.chat.id, f"New user (`{message.chat.id}`) started the bot. `{user}` get 1 point")

            await self.app.send_message(message.chat.id, f"Hello {message.chat.first_name},\n{Config.START_MSG}")


    async def talk_to_admin(self, message):
        if message.text == Config.TALK_TO_ADMIN_COMMAND:
            await self.app.send_message(message.chat.id, "To send your message to admin send message like this:\n \n`/admin [here is your message]`")
        else:
            msg = str(message.text).split(f"{Config.TALK_TO_ADMIN_COMMAND} ")[-1]
            for admin in Config.ADMIN:
                await self.app.send_message(admin, f"**User sends a message!**\n \nUser: `{message.chat.id}`\nMessage: {msg}")
            await self.log.log(message.chat.id, f"User sends a message to Admins.\nMessage: {msg}")
            await self.app.send_message(message.chat.id, f"Your message has been sent to the admins. Thank you!\n \nYour message: {msg}")
    
    async def handle_custom_message(self, message):
        if message.text == Config.CUSTOM_MSG_COMMAND:
            await self.app.send_message(message.chat.id, "With this command you can individualy contact with the users.\n \nex: `/user_123456` message\n \nThis command will automatically send you when user request a movie. You will understand!")
            return
        user = int(str(message.text).split(f" ")[0].split(f"{Config.CUSTOM_MSG_COMMAND}_")[-1])
        msg = str(message.text).split(f"{Config.CUSTOM_MSG_COMMAND}_{user} ")[-1]
        await self.app.send_message(user, msg)
        await self.app.send_message(message.chat.id, f"Message sent to the user (`{user}`)")
        await self.log.log(message.chat.id, f"Admin sent a custom message for user (`{user}`)\nMessage: {msg}")

    def humanbytes(self, size):
        if not size:
            return ""
        power = 2**10
        n = 0
        Dic_powerN = {0: ' ', 1: 'Ki', 2: 'Mi', 3: 'Gi', 4: 'Ti'}
        while size > power:
            size /= power
            n += 1
        return str(round(size, 2)) + " " + Dic_powerN[n] + 'B'